#!/bin/bash

/nfs/guille/a2/rh80apps/cadence/encounter/edi11/bin/encounter -overwrite -init encounter.tcl
